package io.github.virresh.matvt.engine.impl;

import static io.github.virresh.matvt.helper.Helper.helperContext;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.content.Context;
import android.graphics.Path;
import android.graphics.Point;
import android.graphics.PointF;
import android.graphics.Rect;
import android.os.CountDownTimer;
import android.os.Handler;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityWindowInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.Toast;

import androidx.annotation.NonNull;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import io.github.virresh.matvt.helper.Helper;
import io.github.virresh.matvt.view.MouseCursorView;
import io.github.virresh.matvt.view.OverlayView;

public class MouseEmulationEngine {

    private static boolean DPAD_SELECT_PRESSED = false;
    private static String LOG_TAG = "MOUSE_EMULATION";

    CountDownTimer waitToChange;
    CountDownTimer disappearTimer;

    private boolean isInScrollMode = false;

    // service which started this engine
    private AccessibilityService mService;
    private final PointerControl mPointerControl;

    public static int stuckAtSide = 0;
    private int momentumStack;
    private boolean isEnabled;

    public static int bossKey;
    public static int scrollSpeed;
    public static boolean isBossKeyDisabled;
    public static boolean isBossKeySetToToggle;

    private Handler timerHandler;
    private Point DPAD_Center_Init_Point = new Point();
    private Runnable previousRunnable;

    // Configuração do Scroll acompanhando a inversão física para manter a lógica original
    private static final Map<Integer, Integer> scrollCodeMap;
    static {
        Map<Integer, Integer> integerMap = new HashMap<>();
        integerMap.put(KeyEvent.KEYCODE_NUMPAD_8, PointerControl.DOWN);
        integerMap.put(KeyEvent.KEYCODE_NUMPAD_5, PointerControl.UP);
        integerMap.put(KeyEvent.KEYCODE_NUMPAD_6, PointerControl.RIGHT);
        integerMap.put(KeyEvent.KEYCODE_NUMPAD_4, PointerControl.LEFT);
        // Mantendo os botões coloridos originais para scroll se necessário
        integerMap.put(KeyEvent.KEYCODE_PROG_GREEN, PointerControl.DOWN);
        integerMap.put(KeyEvent.KEYCODE_PROG_RED, PointerControl.UP);
        integerMap.put(KeyEvent.KEYCODE_PROG_BLUE, PointerControl.RIGHT);
        integerMap.put(KeyEvent.KEYCODE_PROG_YELLOW, PointerControl.LEFT);
        scrollCodeMap = Collections.unmodifiableMap(integerMap);
    }

    // NOVAS TECLAS DE MOVIMENTO (8=Cima, 5=Baixo, 6=Esquerda, 4=Direita)
    private static final Map<Integer, Integer> movementCodeMap;
    static {
        Map<Integer, Integer> integerMap = new HashMap<>();
        integerMap.put(KeyEvent.KEYCODE_NUMPAD_8, PointerControl.UP);
        integerMap.put(KeyEvent.KEYCODE_NUMPAD_5, PointerControl.DOWN);
        integerMap.put(KeyEvent.KEYCODE_NUMPAD_6, PointerControl.LEFT);
        integerMap.put(KeyEvent.KEYCODE_NUMPAD_4, PointerControl.RIGHT);
        movementCodeMap = Collections.unmodifiableMap(integerMap);
    }

    // Atualizado com as novas teclas numéricas aceitas pelo motor
    private static final Set<Integer> actionableKeyMap;
    static {
        Set<Integer> integerSet = new HashSet<>();
        integerSet.add(KeyEvent.KEYCODE_NUMPAD_8);
        integerSet.add(KeyEvent.KEYCODE_NUMPAD_5);
        integerSet.add(KeyEvent.KEYCODE_NUMPAD_6);
        integerSet.add(KeyEvent.KEYCODE_NUMPAD_4);
        integerSet.add(KeyEvent.KEYCODE_NUMPAD_7); // Clique Esquerdo
        integerSet.add(KeyEvent.KEYCODE_NUMPAD_9); // Clique Direito
        integerSet.add(KeyEvent.KEYCODE_PROG_GREEN);
        integerSet.add(KeyEvent.KEYCODE_PROG_YELLOW);
        integerSet.add(KeyEvent.KEYCODE_PROG_BLUE);
        integerSet.add(KeyEvent.KEYCODE_PROG_RED);
        actionableKeyMap = Collections.unmodifiableSet(integerSet);
    }

    private static final Set<Integer> colorSet;
    static {
        Set<Integer> integerSet = new HashSet<>();
        integerSet.add(KeyEvent.KEYCODE_PROG_GREEN);
        integerSet.add(KeyEvent.KEYCODE_PROG_YELLOW);
        integerSet.add(KeyEvent.KEYCODE_PROG_BLUE);
        integerSet.add(KeyEvent.KEYCODE_PROG_RED);
        colorSet = Collections.unmodifiableSet(integerSet);
    }

    public MouseEmulationEngine (Context c, OverlayView ov) {
        momentumStack = 0;
        MouseCursorView mCursorView = new MouseCursorView(c);
        ov.addFullScreenLayer(mCursorView);
        mPointerControl = new PointerControl(ov, mCursorView);
        mPointerControl.disappear();
    }

    public void init(@NonNull AccessibilityService s) {
        this.mService = s;
        mPointerControl.reset();
        timerHandler = new Handler();
        isEnabled = false;
    }

    private void attachTimer (final int direction) {
        if (previousRunnable != null) {
            detachPreviousTimer();
        }
        previousRunnable = new Runnable() {
            @Override
            public void run() {
                mPointerControl.reappear();
                mPointerControl.move(direction, momentumStack);
                momentumStack += 1;
                timerHandler.postDelayed(this, 30);
            }
        };
        timerHandler.postDelayed(previousRunnable, 0);
    }

    private void attachGesture (final PointF originPoint, final int direction) {
        if (previousRunnable != null) {
            detachPreviousTimer();
        }
        previousRunnable = new Runnable() {
            @Override
            public void run() {
                mPointerControl.reappear();
                mService.dispatchGesture(createSwipe(originPoint, direction, 20 + momentumStack), null, null);
                momentumStack += 1;
                timerHandler.postDelayed(this, 30);
            }
        };
        timerHandler.postDelayed(previousRunnable, 0);
    }

    private void createSwipeForSingle (final PointF originPoint, final int direction) {
        if (previousRunnable != null) {
            detachPreviousTimer();
        }
        previousRunnable = new Runnable() {
            @Override
            public void run() {
                mPointerControl.reappear();
                mService.dispatchGesture(createSwipe(originPoint, direction, 20 + momentumStack), null, null);
                momentumStack += 1;
                timerHandler.postDelayed(this, 30);
            }
        };
        timerHandler.postDelayed(previousRunnable, 0);
    }

    private void detachPreviousTimer () {
        if (disappearTimer != null) {
            disappearTimer.cancel();
        }
        if (previousRunnable != null) {
            timerHandler.removeCallbacks(previousRunnable);
            momentumStack = 0;
            disappearTimer = new CountDownTimer(10000, 10000) {
                @Override
                public void onTick(long l) { }
                @Override
                public void onFinish() { mPointerControl.disappear(); }
            };
            disappearTimer.start();
        }
    }

    private static GestureDescription createClick (PointF clickPoint, long duration) {
        final int DURATION = 1 + (int) duration;
        Path clickPath = new Path();
        clickPath.moveTo(clickPoint.x, clickPoint.y);
        GestureDescription.StrokeDescription clickStroke =
                new GestureDescription.StrokeDescription(clickPath, 0, DURATION);
        GestureDescription.Builder clickBuilder = new GestureDescription.Builder();
        clickBuilder.addStroke(clickStroke);
        return clickBuilder.build();
    }

    private static GestureDescription createSwipe (PointF originPoint, int direction, int momentum) {
        final int DURATION = scrollSpeed + 8;
        Path clickPath = new Path();
        PointF lineDirection = new PointF(originPoint.x + momentum * PointerControl.dirX[direction], originPoint.y + momentum * PointerControl.dirY[direction]);
        clickPath.moveTo(originPoint.x, originPoint.y);
        clickPath.lineTo(lineDirection.x, lineDirection.y);
        GestureDescription.StrokeDescription clickStroke =
                new GestureDescription.StrokeDescription(clickPath, 0, DURATION);
        GestureDescription.Builder clickBuilder = new GestureDescription.Builder();
        clickBuilder.addStroke(clickStroke);
        return clickBuilder.build();
    }

    public boolean perform (KeyEvent keyEvent) {

        // Logica do BossKey mantida intacta
        if (keyEvent.getKeyCode() == bossKey && !isBossKeyDisabled && !isBossKeySetToToggle) {
            if (keyEvent.getAction() == KeyEvent.ACTION_UP) {
                if (waitToChange != null) {
                    waitToChange.cancel();
                    if (isEnabled) return true;
                }
            }
            if (keyEvent.getAction() == KeyEvent.ACTION_DOWN) {
                waitToChange();
                if (isEnabled){
                    isInScrollMode = !isInScrollMode;
                    Toast.makeText(mService, isInScrollMode ? "Scroll Mode: Enabled" : "Scroll Mode: Disabled", Toast.LENGTH_SHORT).show();
                    return true;
                }
            }
        }
        else if (keyEvent.getKeyCode() == bossKey && !isBossKeyDisabled && isBossKeySetToToggle) {
            if (keyEvent.getAction() == KeyEvent.ACTION_DOWN) {
                if (isEnabled && isInScrollMode) {
                    setMouseModeEnabled(false);
                    isInScrollMode = false;
                } else if (isEnabled && !isInScrollMode) {
                    Toast.makeText(mService, "Scroll Mode", Toast.LENGTH_SHORT).show();
                    isInScrollMode = true;
                } else if (!isEnabled) {
                    setMouseModeEnabled(true);
                    isInScrollMode = false;
                }
            }
            return true;
        }
        else if (keyEvent.getKeyCode() == bossKey && isBossKeyDisabled) {
            return false;
        }

        if (keyEvent.getAction() == KeyEvent.ACTION_DOWN && keyEvent.getKeyCode() == KeyEvent.KEYCODE_INFO) {
            if (this.isEnabled) {
                this.isEnabled = false;
                mPointerControl.disappear();
                Toast.makeText(mService, "Dpad Mode", Toast.LENGTH_SHORT).show();
                return true;
            } else {
                this.isEnabled = true;
                mPointerControl.reset();
                mPointerControl.reappear();
                Toast.makeText(mService, "Mouse/Scroll", Toast.LENGTH_SHORT).show();
            }
        }

        if (!isEnabled) {
            return false;
        }

        boolean consumed = false;

        if (keyEvent.getAction() == KeyEvent.ACTION_DOWN){
            if (scrollCodeMap.containsKey(keyEvent.getKeyCode())) {
                if (isInScrollMode || colorSet.contains(keyEvent.getKeyCode()))
                    attachGesture(mPointerControl.getPointerLocation(), scrollCodeMap.get(keyEvent.getKeyCode()));
                else if (!isInScrollMode && stuckAtSide != 0 && keyEvent.getKeyCode() == stuckAtSide)
                    createSwipeForSingle(mPointerControl.getCenterPointOfView(), scrollCodeMap.get(keyEvent.getKeyCode()));
                else if (movementCodeMap.containsKey(keyEvent.getKeyCode()))
                    attachTimer(movementCodeMap.get(keyEvent.getKeyCode()));
                consumed = true;
            }
            // ALTERAÇÃO: Número 7 inicia a detecção do clique esquerdo
            else if(keyEvent.getKeyCode() == KeyEvent.KEYCODE_NUMPAD_7) {
                DPAD_Center_Init_Point = new Point((int) mPointerControl.getPointerLocation().x, (int) mPointerControl.getPointerLocation().y);
                DPAD_SELECT_PRESSED = true;
                consumed = true;
            }
            // ALTERAÇÃO: Número 9 consome o evento no pressionar para o clique direito
            else if(keyEvent.getKeyCode() == KeyEvent.KEYCODE_NUMPAD_9) {
                consumed = true;
            }
        }
        else if (keyEvent.getAction() == KeyEvent.ACTION_UP) {
            if (actionableKeyMap.contains(keyEvent.getKeyCode()) || keyEvent.getKeyCode() == bossKey) {
                detachPreviousTimer();
                consumed = true;
            }
            // ALTERAÇÃO: Número 9 executa a função nativa de Voltar/Menu Global (Ação de clique direito no Android)
            else if (keyEvent.getKeyCode() == KeyEvent.KEYCODE_NUMPAD_9) {
                detachPreviousTimer();
                mService.performGlobalAction(AccessibilityService.GLOBAL_ACTION_BACK); // Simula clique direito/voltar
                consumed = true;
            }
            // ALTERAÇÃO: Número 7 executa a lógica de clique esquerdo
            else if (keyEvent.getKeyCode() == KeyEvent.KEYCODE_NUMPAD_7) {
                DPAD_SELECT_PRESSED = false;
                detachPreviousTimer();
                int action = AccessibilityNodeInfo.ACTION_CLICK;
                Point pInt = new Point((int) mPointerControl.getPointerLocation().x, (int) mPointerControl.getPointerLocation().y);
                
                if (DPAD_Center_Init_Point.equals(pInt)) {
                    List<AccessibilityWindowInfo> windowList = mService.getWindows();
                    boolean wasIME = false, focused = false;
                    for (AccessibilityWindowInfo window : windowList) {
                        if (consumed || wasIME) {
                            break;
                        }
                        List<AccessibilityNodeInfo> nodeHierarchy = findNode(window.getRoot(), action, pInt);
                        for (int i = nodeHierarchy.size() - 1; i >= 0; i--) {
                            if (consumed || focused) {
                                break;
                            }
                            AccessibilityNodeInfo hitNode = nodeHierarchy.get(i);
                            List<AccessibilityNodeInfo.AccessibilityAction> availableActions = hitNode.getActionList();
                            if (availableActions.contains(AccessibilityNodeInfo.AccessibilityAction.ACTION_ACCESSIBILITY_FOCUS)) {
                                focused = hitNode.performAction(AccessibilityNodeInfo.ACTION_ACCESSIBILITY_FOCUS);
                            }
                            if (hitNode.isFocused() && availableActions.contains(AccessibilityNodeInfo.AccessibilityAction.ACTION_SELECT)) {
                                hitNode.performAction(AccessibilityNodeInfo.ACTION_SELECT);
                            }
                            if (hitNode.isFocused() && availableActions.contains(AccessibilityNodeInfo.AccessibilityAction.ACTION_CLICK)) {
                                consumed = hitNode.performAction(AccessibilityNodeInfo.ACTION_CLICK);
                            }
                            if (window.getType() == AccessibilityWindowInfo.TYPE_INPUT_METHOD && !(hitNode.getPackageName()).toString().contains("leankeyboard")) {
                                if (hitNode.getPackageName().equals("com.amazon.tv.ime") && keyEvent.getKeyCode() == KeyEvent.KEYCODE_BACK && helperContext != null) {
                                    InputMethodManager imm = (InputMethodManager) helperContext.getSystemService(Context.INPUT_METHOD_SERVICE);
                                    imm.toggleSoftInput(InputMethodManager.HIDE_IMPLICIT_ONLY, 0);
                                    consumed = wasIME = true;
                                } else {
                                    wasIME = true;
                                    consumed = hitNode.performAction(AccessibilityNodeInfo.ACTION_CLICK);
                                }
                                break;
                            }
                            if ((hitNode.getPackageName().equals("com.google.android.tvlauncher") && availableActions.contains(AccessibilityNodeInfo.AccessibilityAction.ACTION_CLICK))) {
                                if (hitNode.isFocusable()) {
                                    focused = hitNode.performAction(AccessibilityNodeInfo.FOCUS_INPUT);
                                }
                                consumed = hitNode.performAction(AccessibilityNodeInfo.ACTION_CLICK);
                            }
                        }
                    }
                    if (!consumed && !wasIME) {
                        mService.dispatchGesture(createClick(mPointerControl.getPointerLocation(), keyEvent.getEventTime() - keyEvent.getDownTime()), null, null);
                    }
                }
            }
        }
        return consumed;
    }

    private void setMouseModeEnabled(boolean enable) {
        if (enable) {
            this.isEnabled = true;
            isInScrollMode = false;
            mPointerControl.reset();
            mPointerControl.reappear();
            Toast.makeText(mService, "Mouse Mode", Toast.LENGTH_SHORT).show();
        } else {
            this.isEnabled = false;
            mPointerControl.disappear();
            Toast.makeText(mService, "D-Pad Mode", Toast.LENGTH_SHORT).show();
        }
    }

    private void waitToChange() {
        waitToChange = new CountDownTimer(800, 800) {
            @Override
            public void onTick(long l) { }
            @Override
            public void onFinish() { setMouseModeEnabled(!isEnabled); }
        };
        waitToChange.start();
    }

    private List<AccessibilityNodeInfo> findNode (AccessibilityNodeInfo node, int action, Point pInt) {
        if (node == null) {
            node = mService.getRootInActiveWindow();
        }
        List<AccessibilityNodeInfo> nodeInfos = new ArrayList<>();
        node = findNodeHelper(node, action, pInt, nodeInfos);
        return nodeInfos;
    }

    private AccessibilityNodeInfo findNodeHelper (AccessibilityNodeInfo node, int action, Point pInt, List<AccessibilityNodeInfo> nodeList) {
        if (node == null) {
            return null;
        }
        Rect tmp = new Rect();
        node.getBoundsInScreen(tmp);
        if (!tmp.contains(pInt.x, pInt.y)) {
            return null;
        }
        nodeList.add(node);
        AccessibilityNodeInfo result = node;
        int childCount = node.getChildCount();
        for (int i=0; i<childCount; i++) {
            AccessibilityNodeInfo child = findNodeHelper(node.getChild(i), action, pInt, nodeList);
            if (child != null) {
                result = child;
            }
        }
        return result;
    }
}
